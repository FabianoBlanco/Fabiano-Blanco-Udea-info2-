#ifndef CUERPO_H
#define CUERPO_H

#include <iostream>
#include<fstream>
#include <math.h> //librerias principales
using namespace std;

class Cuerpo{

 public:

    double Posx; // posicion en x
    double Posy; // posicion en y
    double Velx; // velocidad en x
    double Vely; //veloccidad en y
    double Masa; // masa del cuerpo
    double a[2]={0.0 , 0.0};

    Cuerpo();

    void F_Atraccion(double _Posx2,double _Posy2,double _Masa2);
    void posicion();

};

Cuerpo::Cuerpo(){ // constructor

    cout<<"posicion  en x"<<endl;
    cin>>Posx;

    cout<<"posicion  en y"<<endl;
    cin>>Posy;

    cout<<"velocidad  en x"<<endl;
    cin>>Velx;

    cout<<"velocidad en y"<<endl;
    cin>>Vely;

    cout<<"masa del cuerpo"<<endl;
    cin>>Masa;



}

void Cuerpo::F_Atraccion(double _Posx2, double _Posy2, double _Masa2){

     double r=0; // distancia entre cuerpo 1 y cuerpo 2
    double angulo; // angulo entre cuerpo 1 y cuerpo 2

    r=pow(_Posx2-Posx,2)+pow(_Posy2-Posy,2); // calculo de discancia entre  dos cuerpos

    angulo=atan2((_Posy2-Posy),(_Posx2-Posx)); // angulo entre dos cuerpos
    a[0]+=(_Masa2/r)*cos(angulo);
    a[1]+=(_Masa2/r)*sin(angulo); // calculo de las aceleraciones en X y Y

}

void Cuerpo::posicion(){ // calculo de la velocidad y de la posicion

    Posx= Posx + Velx + a[0]/2;
    Posy= Posy + Vely + a[1]/2;// calculo de la posicion

    Velx = Velx + a[0];
    Vely = Vely + a[1]; // calculo de la velocidad

}

#endif // CUERPO_H
