/*
 -simulacion de sistema gravitacional

Jhon eduar garcia
jualian Camilo zorro

Informatica II
grupo 01
Augusto salazar
*/


#include <iostream>
#include<cuerpo.h>
#include<vector>
#include<fstream>
#include<string>
using namespace std;

int main(void)
{
    int N_cuerpos=0;
    cout<<"numero de cuerpos"<<endl; // numero de cuerpos del sistema
    cin>>N_cuerpos;

    vector <Cuerpo> Sistema(N_cuerpos); // vector con todos los  planetas del sistema

    string archivo;
    cout<<"nombre del archivo de salida: ";
    getline(cin,archivo);
    getline(cin,archivo);

    ofstream file;
    file.open(archivo,ios_base::app);  //archivo de salida

    for(int it=0;it<10;it++){ // numero de veces que calculara las posiciones

        for(int i=0;i<N_cuerpos;i++){ // calculo de la aceleracion resultante de cada cuerpo
            for(int j=0;j<N_cuerpos;j++){
                if(i!=j){
                    Sistema[i].F_Atraccion(Sistema[j].Posx,Sistema[j].Posy,Sistema[j].Masa);}}
            Sistema[i].posicion();//calculo de la posicion de un cuerpo en 1 segundo
            file<<Sistema[i].Posx<<"  "<<Sistema[i].Posy<<" "; // escritura en el archivo dela posicion en X y Y
        }
        for(int i =0;i<N_cuerpos;i++){ // reinicio de las aceleraciones en cero para pasar a la siguiente iteracion de la simulacion
            Sistema[i].a[0]=0;
            Sistema[i].a[1]=0;
        }

    }



file.close();
}
